Expose a local socks5 server behind a NAT or firewall to the internet. 

- VPS Linux   

https://github.com/fatedier/frp/releases

./frps &

- Windows

edit frps.ini
change VPS ip
run socks5.exe
run start.bat

This will create a SOCKS-proxy on vps ip port 32000



