Expose a local SOCKS5 server behind a NAT or firewall to the internet. 

- Windows

edit frps.ini
change VPS ip
run socks5.exe
run start.bat

- VPS Linux   

https://github.com/fatedier/frp/releases

./frps &

This will create a SOCKS-proxy on vps ip port 32000



